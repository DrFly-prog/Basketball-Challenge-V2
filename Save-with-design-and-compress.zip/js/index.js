import { auth } from './Js/firebaseConfig.js';
import { onAuthStateChanged, signOut } from "firebase/auth";

// Vérifie l'état de connexion de l'utilisateur
onAuthStateChanged(auth, (user) => {
  if (user) {
    console.log("Utilisateur connecté :", user.email);
  } else {
    // Redirection vers la page de connexion si l'utilisateur n'est pas connecté
    window.location.href = "Html/login.html";
  }
});

// Déconnexion de l'utilisateur
document.getElementById("logoutButton").addEventListener("click", () => {
  signOut(auth).then(() => {
    window.location.href = "Html/login.html";
  }).catch((error) => {
    console.error("Erreur de déconnexion :", error);
  });
});
