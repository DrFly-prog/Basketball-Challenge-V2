import { getDatabase, ref, set } from "firebase/database";

// Ajouter une nouvelle équipe
export function createTeam(teamId, teamData) {
  const db = getDatabase();
  return set(ref(db, 'teams/' + teamId), teamData);
}
