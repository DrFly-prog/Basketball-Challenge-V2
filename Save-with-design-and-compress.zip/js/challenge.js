import { getDatabase, ref, set } from "firebase/database";

// Ajouter un nouveau challenge
export function createChallenge(challengeId, challengeData) {
  const db = getDatabase();
  return set(ref(db, 'challenges/' + challengeId), challengeData);
}
