import { signUpUser } from './auth.js';

document.getElementById("signupForm").addEventListener("submit", async (event) => {
  event.preventDefault();

  const pseudo = document.getElementById("pseudo").value;
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  const messageElement = document.getElementById("signupMessage");

  try {
    await signUpUser(email, password, pseudo);
    messageElement.textContent = "Inscription réussie ! Vous pouvez maintenant vous connecter.";
    messageElement.style.color = "green";
  } catch (error) {
    messageElement.textContent = error.message;
    messageElement.style.color = "red";
  }
});
